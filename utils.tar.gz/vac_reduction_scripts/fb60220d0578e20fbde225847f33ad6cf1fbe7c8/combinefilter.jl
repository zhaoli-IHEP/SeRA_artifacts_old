###########################
function main()::Nothing
###########################

  n_type = 1
  combine_file = open( "vac_ibp.inc", "w" )
  for typei in 1:n_type
    file = open( "results/vac2loopT$(typei)/kira_integrals_vac2loopT$(typei).inc", "r" )
    content_str = read( file, String )
    close( file )
    for id in 1:n_type
      content_str = replace( content_str, "id vac2loopT$(id)(" => "id vacloopT$(id)(d?," )
      content_str = replace( content_str, "vac2loopT$(id)(" => "vacloopT$(id)(d," )
    end # for id
    write( combine_file, content_str )
  end # for typei
  close( combine_file )

end # function main

#######
main()
#######

